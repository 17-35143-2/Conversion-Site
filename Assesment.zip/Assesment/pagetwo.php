<!DOCTYPE html>
<html>
<body>
<fieldset>
<h1 style="color:red;text-align:left">Page 2 [Conversion Site]</h1>
<h2 style="color:red;text-align:left">Conversion Site</h2>


<h5> <a href="pageone.php">Home</a></h5>

<h5> <a href="pagetwo.php">Conversion Rate</a></h5>


 <h5> <a href="pagethree.php">History</a></h5>

 <h7 style="color:red;text-align:left">Conversion Site</h7><br><br>

 <input type="text" value="feet to inch "> 
 

<input type="text" value="1">
 

 
<input type="text" value="12">
 
 <br/>
 
</body>
</fieldset>
</html>

<?php


?>   


