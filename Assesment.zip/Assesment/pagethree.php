<!DOCTYPE html>
<html>
<body>
<fieldset>
<h1 style="color:red;text-align:left">Page 3 [History]</h1>
<h2 style="color:red;text-align:left">Conversion Site</h2>


<h5> <a href="pageone.php">1. Home</a></h5>

<h5> <a href="pagetwo.php">2. Conversion Rate</a></h5>


 <h5> <a href="pagethree.php">3. History</a></h5>

 <h7 style="color:red;text-align:left">Converter History</h7><br>
 
 1. feet to inch  <input type="text" value="3"> <input type="text" value="36">
 
 2. inch to feet  <input type="text" value="1"> <input type="text" value="12">
 
 
 

</body>
</fieldset>
</html>

<?php


?>   


