<!DOCTYPE html>
<html>
<body>
<fieldset>
<h1 style="color:red;text-align:left">Page 1 [Home]</h1>
<h2 style="color:red;text-align:left">Conversion Site</h2>


<h5> <a href="pageone.php">1. Home</a></h5>

<h5> <a href="pagetwo.php">2. Conversion Rate</a></h5>


 <h5> <a href="pagethree.php">3. History</a></h5>

 <h7 style="color:red;text-align:left">Converter</h7><br>
 <fieldset>
 feet to inch 
 </fieldset>
 <br><br>
 
 Value:<input type="text" value="3"><br><br>

<br><br><br>
 
Result:<input type="text" value="36">
 
 <br/><br>
 <input type="Submit" value="Submit">
 
</body>
</fieldset>
</html>

<?php


?>   


